#include <stdio.h>
main(){
    char req[1024];
    scanf("%s", &req);
    printf("%s",req);
}